package com.example.administrator.myapplication.activity.coorinatorlayout;

import android.os.Bundle;

import com.example.administrator.myapplication.R;
import com.example.administrator.myapplication.activity.BaseActivity;

/**
 * Created by Administrator on 2016/7/11 0011.
 */
public class EasyCoordinatorLayoutActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easycoord);
        initView();
        initData();
    }

    private void initData() {
    }

    private void initView() {
    }
}
